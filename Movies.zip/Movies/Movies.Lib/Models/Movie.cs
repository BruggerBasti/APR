﻿using System;
namespace Movies.Lib.Models
{
	public class Movie
	{
		
	}
}

