﻿using System;
namespace Movies.Lib.Services
{
	public class MemoryRepository
	{
		// TODO: implement repository
	}
}

